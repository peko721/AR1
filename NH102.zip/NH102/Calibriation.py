# -*- coding: utf-8 -*-
"""
Created on Fri Aug 23 10:18:17 2024

@author: zhangw16
"""

import math
import pandas as pd

# 读取excel文件
df = pd.read_excel('C:\\Users\\zhangw16\\Desktop\\CE003Inside.xlsx')

# 选择要转换为列表的列,假设你的x和y坐标列表如下：
x_coords= df['X'].tolist()
y_coords= df['Y'].tolist()

# 现在column_data就是一个包含所选列数据的列表
# print(column_data)

# 假设你的x和y坐标列表如下：
# x_coords = [x1, x2, x3, ..., x60]
# y_coords = [y1, y2, y3, ..., y60]
x_sortedlist=[]
y_sortedlist=[]
# 假设你的目标点为(target_x, target_y)


target_x = 392.838 
target_y = 124.321

# 将x和y坐标组合成点的列表
points = list(zip(x_coords, y_coords))

# 定义一个函数，计算两点之间的距离
def distance(point1, point2):
    return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

# 计算每个点到目标点的距离，并将结果存储在一个列表中
# distances = [distance(point, (target_x, target_y)) for point in points]
distances = [(distance(point, (target_x, target_y)), idx) for idx, point in enumerate(points)]

# 通过将距离和点组合成元组，然后按距离排序，找到距离最小的两个点
closest_points = sorted(zip(distances, points))[:2]
closest_points_idx = sorted(distances)[:2]



option1=closest_points[0][1]
option2=closest_points[1][1]

if abs(option1[0]-target_x)<abs(option2[0]-target_x):
    x_nextlinestart=option2[0]
    y_nextlinestart=option2[1]
    x_next=option1[0]
    y_next=option1[1]
    indx=closest_points_idx[0][1]
    indx_s=closest_points_idx[1][1]
else:
    x_nextlinestart=option1[0]
    y_nextlinestart=option1[1]
    x_next=option2[0]
    y_next=option2[1]
    indx=closest_points_idx[1][1]
    indx_s=closest_points_idx[0][1]
x_sortedlist.append(target_x)
y_sortedlist.append(target_y)
x_sortedlist.append(x_next)
y_sortedlist.append(y_next)
del x_coords[indx]
del y_coords[indx]
del x_coords[indx_s-1]
del y_coords[indx_s-1]
target_x=x_next
target_y=y_next
co=1
linenumber=1
while(co<33):
    if linenumber>21:
        break
    points = list(zip(x_coords, y_coords))
    distances = [(distance(point, (target_x, target_y)), idx) for idx, point in enumerate(points)]

    # 通过将距离和点组合成元组，然后按距离排序，找到距离最小的两个点
    closest_points = sorted(zip(distances, points))[:2]
    closest_points_idx = sorted(distances)[:2]
    if linenumber<21:
        option1=closest_points[0][1]
        option2=closest_points[1][1]
        
        if abs(option1[0]-target_x)<abs(option2[0]-target_x):
            x_next=option1[0]
            y_next=option1[1]
            indx=closest_points_idx[0][1]
        else:
            x_next=option2[0]
            y_next=option2[1]
            indx=closest_points_idx[1][1]
        x_sortedlist.append(x_next)
        y_sortedlist.append(y_next)
        target_x=x_next
        target_y=y_next
        del x_coords[indx]
        del y_coords[indx]
    if linenumber==21:
        option1=closest_points[0][1]
        option2=closest_points[1][1]
        if closest_points[0][0][0]<closest_points[1][0][0]:
            x_next=option1[0]
            y_next=option1[1]
            indx=closest_points_idx[0][1]
        else:
            x_next=option2[0]
            y_next=option2[1]
            indx=closest_points_idx[1][1]
        x_sortedlist.append(x_next)
        y_sortedlist.append(y_next)
        target_x=x_next
        target_y=y_next
        del x_coords[indx]
        del y_coords[indx]

    co=co+1
    if co>31:
        if linenumber==21 and len(x_coords)==1:
            x_sortedlist.append(x_coords[0])
            y_sortedlist.append(y_coords[0])
            break
        else:
            if len(x_coords)<33 and linenumber<21:
                x_sortedlist.append(x_nextlinestart)
                y_sortedlist.append(y_nextlinestart)
                target_x=x_nextlinestart
                target_y=y_nextlinestart
            else:
    
                x_sortedlist.append(x_nextlinestart)
                y_sortedlist.append(y_nextlinestart)
            
                target_x=x_nextlinestart
                target_y=y_nextlinestart
                
                points = list(zip(x_coords, y_coords))
                distances = [(distance(point, (target_x, target_y)), idx) for idx, point in enumerate(points)]
                closest_points = sorted(zip(distances, points))[:2]
                closest_points_idx = sorted(distances)[:2]
                
                option1=closest_points[0][1]
                option2=closest_points[1][1]
    
                if abs(option1[0]-target_x)<abs(option2[0]-target_x):
                    x_nextlinestart=option2[0]
                    y_nextlinestart=option2[1]
                    x_next=option1[0]
                    y_next=option1[1]
                    indx=closest_points_idx[0][1]
                    indx_s=closest_points_idx[1][1]
                else:
                    x_nextlinestart=option1[0]
                    y_nextlinestart=option1[1]
                    x_next=option2[0]
                    y_next=option2[1]
                    indx=closest_points_idx[1][1]
                    indx_s=closest_points_idx[0][1]
                    
                x_sortedlist.append(x_next)
                y_sortedlist.append(y_next)
                target_x=x_next
                target_y=y_next
                del x_coords[indx]
                del y_coords[indx]
                del x_coords[indx_s-1]
                del y_coords[indx_s-1]
        co=1
        linenumber=linenumber+1










# 打印结果
for i, (distance, point) in enumerate(closest_points, 1):
    print(f"The {i}-th closest point is {point} with a distance of {distance}")