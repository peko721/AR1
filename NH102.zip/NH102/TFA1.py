# -*- coding: utf-8 -*-
"""
Created on Wed Aug  7 19:21:24 2024

@author: zhangw16
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 15:19:02 2024

@author: ZhangW16
"""

import numpy as np
import pandas as pd

# 读取Excel文件 这个是外面的相机
df = pd.read_excel('C:\\Users\\zhangw16\\Desktop\\CE001Outsidesorted.xlsx',sheet_name="Sheet1")


# 创建一个新的列，用于表示每个数据的组别
df['group'] = df.index // 32

# 对每个组的数据按照第二列的值进行排序，并将结果存储在一个新的DataFrame中
sorted_df = pd.concat(df[df['group'] == i].sort_values(by='Y') for i in range(21))


# 删除新DataFrame中的'group'列
sorted_df = sorted_df.drop(columns='group')
sorted_df = sorted_df.reset_index(drop=True)
sorted_df.to_excel('C:\\Users\\zhangw16\\Desktop\\Sorteddf.xlsx',sheet_name="Sheet1")

# 将数据转换为numpy数组
data = sorted_df.values

# 将一维数组重塑为20*20的二维数组
matrixpiexl = data.reshape(21, 32, 2)

# 创建一个20*20的零矩阵
matrixWorld= np.zeros((21, 32, 2), dtype=int)

# 使用两个嵌套循环来为矩阵的每个元素赋值
for i in range(21):
    for j in range(32):
        matrixWorld[i][j] = [i*20, j*20]

# 给定点A
#point_A = np.array([2219,2607])
#point_A = np.array([353,206])
#point_A = np.array([253,661])
#point_A = np.array([894,2000])
#point_A = np.array([898,2332])
#point_A = np.array([1297,2670])
point_A = np.array([2666,2600])
#point_A = np.array([855,3150])
#point_A = np.array([2148,596])
#1648 3075

# 计算矩阵中每个点与A的欧氏距离
distances = np.sqrt(np.sum((matrixpiexl - point_A) ** 2, axis=2))

# 找出最近距离的索引
min_distance_index = np.unravel_index(np.argmin(distances, axis=None), distances.shape)
value=matrixpiexl[min_distance_index]
wordl=matrixWorld[min_distance_index]
if point_A[1]>=value[1]:#点在右侧
    if point_A[0]>=value[0]:#点在下侧
    # 点在右下
    #value的右和下的2个点
        valueright=matrixpiexl[min_distance_index[0],min_distance_index[1]+1]
        valuedown=matrixpiexl[min_distance_index[0]+1,min_distance_index[1]]
        ActaulX=20*abs((point_A[0]-value[0])/(valuedown[0]-value[0]))
        ActaulY=20*abs((point_A[1]-value[1])/(valueright[1]-value[1]))
        FX=wordl[0]+ActaulX
        FY=wordl[1]+ActaulY
    else:
        #点在右上
        valueright=matrixpiexl[min_distance_index[0],min_distance_index[1]+1]
        valueup=matrixpiexl[min_distance_index[0]-1,min_distance_index[1]]
        ActaulX=20*abs((point_A[0]-value[0])/(valueup[0]-value[0]))
        ActaulY=20*abs((point_A[1]-value[1])/(valueright[1]-value[1]))
        FX=wordl[0]-ActaulX
        FY=wordl[1]+ActaulY
else:
    if point_A[0]>=value[0]:#点在下侧
    # 点在左下
    #value的右和下的2个点
        valueleft=matrixpiexl[min_distance_index[0],min_distance_index[1]-1]
        valuedown=matrixpiexl[min_distance_index[0]+1,min_distance_index[1]]
        ActaulX=20*abs((point_A[0]-value[0])/(valuedown[0]-value[0]))
        ActaulY=20*abs((point_A[1]-value[1])/(valueleft[1]-value[1]))
        FX=wordl[0]+ActaulX
        FY=wordl[1]-ActaulY
    else:
        #点在左上
        valueleft=matrixpiexl[min_distance_index[0],min_distance_index[1]-1]
        valueup=matrixpiexl[min_distance_index[0]-1,min_distance_index[1]]
        ActaulX=20*abs((point_A[0]-value[0])/(valueup[0]-value[0]))
        ActaulY=20*abs((point_A[1]-value[1])/(value[1]-valueleft[1]))
        FX=wordl[0]-ActaulX
        FY=wordl[1]-ActaulY

# 找到最近的点
# nearest_point = matrix[min_distance_index]

# print("The nearest point to A in the matrix is:", nearest_point)