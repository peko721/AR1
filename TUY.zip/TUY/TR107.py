# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 13:58:56 2024

@author: zhangw16
"""


#import os
#os.rmdir(r"C:\Reverse\210103123924\RE Data")  # path是文件夹路径，注意文件夹需要时空的才能被删除
import PySimpleGUI as sg 
import os.path
import PIL.Image
import io
import base64
import shutil
import pandas as pd
import joblib
from joblib import parallel_backend
import multiprocessing as mp
fontSize = 1
fontSize1 = 0
def convert_to_bytes(file_or_bytes, resize=None):
    '''
    Will convert into bytes and optionally resize an image that is a file or a base64 bytes object.
    Turns into  PNG format in the process so that can be displayed by tkinter
    :param file_or_bytes: either a string filename or a bytes base64 image object
    :type file_or_bytes:  (Union[str, bytes])
    :param resize:  optional new size
    :type resize: (Tuple[int, int] or None)
    :return: (bytes) a byte-string object
    :rtype: (bytes)
    '''
    if isinstance(file_or_bytes, str):
        img = PIL.Image.open(file_or_bytes)
    else:
        try:
            img = PIL.Image.open(io.BytesIO(base64.b64decode(file_or_bytes)))
        except Exception as e:
            dataBytesIO = io.BytesIO(file_or_bytes)
            img = PIL.Image.open(dataBytesIO)

    cur_width, cur_height = img.size
    if resize:
        new_width, new_height = resize
        scale = min(new_height/cur_height, new_width/cur_width)
        img = img.resize((int(cur_width*scale), int(cur_height*scale)), PIL.Image.LANCZOS)
    bio = io.BytesIO()
    img.save(bio, format="PNG")
    del img
    return bio.getvalue()

sg.ChangeLookAndFeel('GreenTan')      

# ------ Menu Definition ------ #      
menu_def = [['File', ['Open', 'Save', 'Exit', 'Properties']],      
            ['Edit', ['Paste', ['Special', 'Normal', ], 'Undo'], ],      
            ['Help', 'About...'], ]      

# ------ Column Definition ------ #      
column1 = [[sg.Text('Column 1', background_color='#F7F3EC', justification='center', size=(10, 1))],      
            [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 1')],      
            [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 2')],      
            [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 3')]]      

    
#2021-04-07-14-50-46  AR1.0 2 6 测试点 carrier 48 一共4个测试点
#210407190452  AR1.1 5 6 测试点 carrier 39 一共12个测试点
layout = [[sg.Menu(menu_def, tearoff=True)],      
    [sg.Text('Fly In', size=(50, 1), justification='center', font=("Helvetica", 20), relief=sg.RELIEF_RIDGE)],    
    [sg.Text('Wavelength Start'),sg.Text('Wavelength End'),sg.Text('Damping '),sg.Text('Pruduction Series'),sg.Text('2sise or 1side? '),sg.Text('+ 4nmETC? '),sg.Text('FixPoint?'),sg.Text('      R0Corr'),sg.Text('       RBCorr'),sg.Text('     ETCThic'),sg.Text('ETCThic1side'),sg.Text(' Iteration')],      
    [sg.InputText('420',key='wavestart',size=(15, 1)),sg.InputText('680',key='waveend',size=(15, 1)),sg.InputText('2',key='U',size=(8, 1)),sg.InputCombo(('AR1.0', 'AR1.1','AR1.3','AR4.1','AR4.0','AR2.1','AR1.0P'), size=(10, 1)),sg.InputCombo(('1-side','2-side'), key="Side1or2",size=(10, 1)),sg.InputCombo(('only AR','AR ETC'),key='ETC',size=(10, 1)),sg.InputText(('6'),key='Fixpoi',size=(10, 1)),
     sg.InputText('0',key='R0Corr',size=(10, 1)),sg.InputText('0',key='RBCorr',size=(10, 1)),sg.InputText('4',key='ETCThic',size=(8, 1)),sg.InputText('3',key='ETCThic1s',size=(8, 1)),sg.InputText('10',key='Iter',size=(10, 1))],         
    [sg.Text('R0RB', size=(8, 1)), sg.Input(), sg.FileBrowse(),sg.Text('Spectrum', size=(8, 1)), sg.Input(), sg.FileBrowse(),sg.Submit()],
    [sg.Image(key='-IMAGE-'),sg.Image(key='-IMAGE1-'),sg.Image(key='-IMAGEfle-')],
    [sg.InputText(('RDP1'), key='RDP1',size=(10, 1)),sg.InputText(('RDP2'), key='RDP2',size=(10, 1)),sg.InputText(('RDP3'), key='RDP3',size=(10, 1)),sg.InputText(('RDP4'), key='RDP4',size=(10, 1)),
     sg.InputText(('RDP5'), key='RDP5',size=(10, 1)),sg.InputText(('RDP6'), key='RDP6',size=(10, 1)),sg.InputText(('RDP7'), key='RDP7',size=(10, 1)),sg.InputText((''), key='Blank',size=(10, 1))],
    [sg.InputText((''), key='D1DES',size=(10, 1)),sg.InputText((''), key='D2DES',size=(10, 1)),sg.InputText((''), key='D3DES',size=(10, 1)),sg.InputText((''), key='D4DES',size=(10, 1)),
     sg.InputText((''), key='D5DES',size=(10, 1)),sg.InputText((''), key='D6DES',size=(10, 1)),sg.InputText((''), key='D7DES',size=(10, 1)),sg.InputText(('Design'), key='Desig',size=(10, 1)),sg.Text('Lab File Name')],
    [sg.InputText((''), key='D1REV',size=(10, 1)),sg.InputText((''), key='D2REV',size=(10, 1)),sg.InputText((''), key='D3REV',size=(10, 1)),sg.InputText((''), key='D4REV',size=(10, 1)),
     sg.InputText((''), key='D5REV',size=(10, 1)),sg.InputText((''), key='D6REV',size=(10, 1)),sg.InputText((''), key='D7REV',size=(10, 1)),sg.InputText(('Rever'), key='Reverse',size=(10, 1)),sg.Button('Save',size=(10,1))],
    [sg.InputText(('Y'), key='YV',size=(10, 1)),sg.InputText(('L'), key='L2V',size=(10, 1)),sg.InputText(('a'), key='a2V',size=(10, 1)),sg.InputText(('b'), key='b2V',size=(10, 1)),
     sg.InputText(('Y1side'), key='L1V',size=(10, 1)),sg.InputText(('L1side'), key='L1V',size=(10, 1)),sg.InputText(('a1side'), key='a1V',size=(10, 1)),sg.InputText(('b1side'), key='b1V',size=(10, 1))],
    [sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1)),
     sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1)),sg.InputText((''),size=(10, 1))],
    [sg.InputText((''), key='Y2S',size=(10, 1)),sg.InputText((''), key='L2S',size=(10, 1)),sg.InputText((''), key='a2S',size=(10, 1)),sg.InputText((''), key='b2S',size=(10, 1)),
     sg.InputText((''), key='Y1S',size=(10, 1)),sg.InputText((''), key='L1S',size=(10, 1)),sg.InputText((''), key='a1S',size=(10, 1)),sg.InputText((''), key='b1S',size=(10, 1)),sg.InputText(('4.08'), key='Bareglass',size=(12, 1))],
  
    [sg.ProgressBar(4, orientation='h', size=(108, 10), key='progbar',bar_color=('green', 'white'))],
    [sg.Button('Run',size=(8,1)),sg.Button('Reset',size=(8,1)), sg.Cancel()]]    



window = sg.Window('Everything bagel', layout, default_element_size=(40, 1), grab_anywhere=False)

new_size=int(391),int(278)     
image_list = []
image_index = 0
while True:
    # event, values = window.read()
    # if values['ETC']=="only AR":
    #     window.Element('Side1or2').Update("2-side")
    # side12=values['Side1or2'] 
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Cancel':	# if user closes window or clicks cancel
        break
    #ird=int(values['ird'])
    if values['ETC']=="only AR":
        window.Element('Side1or2').Update("2-side")
    if values['ETC']=="AR ETC":
        sg.popup('要确定Only AR的图谱已被反演')
    if values['ETC']=="only AR" and values['Browse0'][-5]=="C":  
        sg.popup('图谱选错')
    # if values['ETC']=="AR ETC" and values['Browse0'][-5]!="C":  
    #     sg.popup('图谱选错')
    if values['Browse'][-5]!="B":  
         sg.popup('R0RB选错')
    def cubic_interpolate_R(wavelength,R):
        f_r=interp1d(wavelength,R,kind="cubic")
        return f_r
    
    # Norm input each single layer n and k value
    def cubic_interpolate(wavelength,n,k):
        '''
        wavelength: the range of wavelength
        n: refractive index represent density
        k: extinction Coefficient represent absorbing
        '''
        f_n=interp1d(wavelength,n,kind="cubic")
        f_k=interp1d(wavelength,k,kind="cubic")
        return f_n,f_k
    
    # Function Func based on input layer thickness calculated correspond 1-sided spectrum
    def Func(variable,i,GG3_ni):
        '''
        variable: contain each layer random thickness
        i: 1 point wavelength
        Note: for AR 1.0 fix first SiO2 layer
        '''
    
        if recipe_id == "AR1.1" or recipe_id == "AR1.0" or recipe_id == "AR1.0P":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_5_d  = variable[3,0]
            RDP_6_d  = variable[4,0]
            RDP_7_8_d = variable[5,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                            RDP_3_d,RDP_4_d,
                            RDP_5_d,RDP_6_d,
                            RDP_7_8_d]
        if  recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_7_8_d = variable[3,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                                       RDP_3_d,RDP_4_d,RDP_7_8_d]
        
        substrate = TransferMatrix.boundingLayer(1, GG3_ni)
        Layer_1 = TransferMatrix.layer(RDP_1_n[i], Layer_thickness_data[0], wavelength_range[i])
        substrate.appendRight(Layer_1)
        
        Layer_2 = TransferMatrix.layer(RDP_2_n[i], Layer_thickness_data[1], wavelength_range[i])
        substrate.appendRight(Layer_2)
        
        Layer_3 = TransferMatrix.layer(RDP_3_n[i], Layer_thickness_data[2], wavelength_range[i])
        substrate.appendRight(Layer_3)
        
        Layer_4 = TransferMatrix.layer(RDP_4_n[i], Layer_thickness_data[3], wavelength_range[i])
        substrate.appendRight(Layer_4)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
            Layer_5 = TransferMatrix.layer(RDP_5_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_5)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
            Layer_6 = TransferMatrix.layer(RDP_6_n[i], Layer_thickness_data[5], wavelength_range[i])
            substrate.appendRight(Layer_6)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[6], wavelength_range[i])
            substrate.appendRight(Layer_7)
        if recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_7)
        
        R, T = solvePropagation(substrate)
        if side12=="2-side":
            R0=((1-GG3_ni)/(1+GG3_ni))**2
            # side_2=(R0b+((1-R0b)**2)*(np.abs(R**2))/(1-R0b*(np.abs(R**2))))*100
            side_2=(R0+((1-R0)**2)*(np.abs(R**2))/(1-R0*(np.abs(R**2))))*100 
            R_ref=side_2
            # 首先量测光谱-R0=Rb
            #再加上Rb,也就是把581行的R0换成Rb
        else:
            R_ref=np.abs(R**2)*100
        
        return [R_ref]
        
    def Deriv(abc,i,qa,GG3_ni):  # 对函数求偏导  
        x1 = abc.copy()  
        x2 = abc.copy()  
        x1[qa,0] -= 0.01 
        x2[qa,0] += 0.01
        # p1 = FuncBM(x1,i,R01[i]/100)  
        # p2 = FuncBM(x2,i,R01[i]/100)  
        p1 = Func(x1,i,GG3_ni)  
        p2 = Func(x2,i,GG3_ni) 
        d = (p2[0]-p1[0])*1/(0.02)
        return d
    
    def FuncBM(variable,i,R0b,GG3_ni):
        if recipe_id == "AR1.1" or recipe_id == "AR1.0" or recipe_id == "AR1.0P":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_5_d  = variable[3,0]
            RDP_6_d  = variable[4,0]
            RDP_7_8_d = variable[5,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                            RDP_3_d,RDP_4_d,
                            RDP_5_d,RDP_6_d,
                            RDP_7_8_d]

        if  recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_7_8_d = variable[3,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                                       RDP_3_d,RDP_4_d,RDP_7_8_d]
        
        substrate = TransferMatrix.boundingLayer(1, GG3_ni)
        Layer_1 = TransferMatrix.layer(RDP_1_n[i], Layer_thickness_data[0], wavelength_range[i])
        substrate.appendRight(Layer_1)
        
        Layer_2 = TransferMatrix.layer(RDP_2_n[i], Layer_thickness_data[1], wavelength_range[i])
        substrate.appendRight(Layer_2)
        
        Layer_3 = TransferMatrix.layer(RDP_3_n[i], Layer_thickness_data[2], wavelength_range[i])
        substrate.appendRight(Layer_3)
        
        Layer_4 = TransferMatrix.layer(RDP_4_n[i], Layer_thickness_data[3], wavelength_range[i])
        substrate.appendRight(Layer_4)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_5 = TransferMatrix.layer(RDP_5_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_5)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_6 = TransferMatrix.layer(RDP_6_n[i], Layer_thickness_data[5], wavelength_range[i])
            substrate.appendRight(Layer_6)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[6], wavelength_range[i])
            substrate.appendRight(Layer_7)
        if  recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_7)
        R, T = solvePropagation(substrate)
        if side12=="2-side":
            # R0=((1-GG3_n[i])/(1+GG3_n[i]))**2
            side_2=(R0b+((1-R0b)**2)*(np.abs(R**2))/(1-R0b*(np.abs(R**2))))*100
            # side_2=(R0+((1-R0)**2)*(np.abs(R**2))/(1-R0*(np.abs(R**2))))*100 
            R_ref=side_2
            # 首先量测光谱-R0=Rb
            #再加上Rb,也就是把581行的R0换成Rb
        else:
            R_ref=np.abs(R**2)*100
        
        return [R_ref]
    def DerivBM(abc,i,qa,R0Bi,GG3_ni):  # 对函数求偏导
        R0B100=R0Bi/100
        x1 = abc.copy()  
        x2 = abc.copy()  
        x1[qa,0] -= 0.01 
        x2[qa,0] += 0.01
        p1 = FuncBM(x1,i,R0B100,GG3_ni)  
        p2 = FuncBM(x2,i,R0B100,GG3_ni)  
        # p1 = Func(x1,i)  
        # p2 = Func(x2,i) 
        d = (p2[0]-p1[0])*1/(0.02)
        return d
    
    def FuncVA(variable,i,R0b):
        '''
        variable: contain each layer random thickness
        i: 1 point wavelength
        Note: for AR 1.0 fix first SiO2 layer
        '''
    
        if recipe_id == "AR1.1" or recipe_id == "AR1.0" or recipe_id == "AR1.0P":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_5_d  = variable[3,0]
            RDP_6_d  = variable[4,0]
            RDP_7_8_d = variable[5,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                            RDP_3_d,RDP_4_d,
                            RDP_5_d,RDP_6_d,
                            RDP_7_8_d]
            if ETC==1:
                RDP_9_d = variable[6,0]
                Layer_thickness_data=[RDP_1_d,RDP_2_d,
                            RDP_3_d,RDP_4_d,
                            RDP_5_d,RDP_6_d,
                            RDP_7_8_d,
                            RDP_9_d]
        if  recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0":
            RDP_1_d  = 25
            RDP_2_d  = variable[0,0]
            RDP_3_d  = variable[1,0]
            RDP_4_d  = variable[2,0]
            RDP_7_8_d = variable[3,0]
            Layer_thickness_data=[RDP_1_d,RDP_2_d,
                                       RDP_3_d,RDP_4_d,RDP_7_8_d]
        
        substrate = TransferMatrix.boundingLayer(1, GG3_n[i])
        Layer_1 = TransferMatrix.layer(RDP_1_n[i], Layer_thickness_data[0], wavelength_range[i])
        substrate.appendRight(Layer_1)
        
        Layer_2 = TransferMatrix.layer(RDP_2_n[i], Layer_thickness_data[1], wavelength_range[i])
        substrate.appendRight(Layer_2)
        
        Layer_3 = TransferMatrix.layer(RDP_3_n[i], Layer_thickness_data[2], wavelength_range[i])
        substrate.appendRight(Layer_3)
        
        Layer_4 = TransferMatrix.layer(RDP_4_n[i], Layer_thickness_data[3], wavelength_range[i])
        substrate.appendRight(Layer_4)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_5 = TransferMatrix.layer(RDP_5_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_5)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_6 = TransferMatrix.layer(RDP_6_n[i], Layer_thickness_data[5], wavelength_range[i])
            substrate.appendRight(Layer_6)
        if recipe_id == "AR1.0" or  recipe_id == "AR1.1"  or recipe_id == "AR1.0P": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[6], wavelength_range[i])
            substrate.appendRight(Layer_7)
        if  recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0": 
            Layer_7 = TransferMatrix.layer(RDP_7_8_n[i], Layer_thickness_data[4], wavelength_range[i])
            substrate.appendRight(Layer_7)
        if ETC == 1 and recipe_id == "AR1.1": 
             Layer_8 = TransferMatrix.layer(RDP_9_n[i], Layer_thickness_data[7], wavelength_range[i])
             substrate.appendRight(Layer_8)
        # if side12=="1-side":
        #     substrate.setPhi(45)
        R, T = solvePropagation(substrate)
        if side12=="2-side":
            # R0=((1-GG3_n[i])/(1+GG3_n[i]))**2
            side_2=(R0b+((1-R0b)**2)*(np.abs(R**2))/(1-R0b*(np.abs(R**2))))*100
            # side_2=(R0+((1-R0)**2)*(np.abs(R**2))/(1-R0*(np.abs(R**2))))*100 
            R_ref=side_2
            # 首先量测光谱-R0=Rb
            #再加上Rb,也就是把581行的R0换成Rb
        else:
            R_ref=np.abs(R**2)*100
        
        return [R_ref]


    text1=values[1]#开始日期
    text2=values['Side1or2']#产品系列
    skipdate=0
    neediside=0
    # if values['need1side']=="Yes":
    #     neediside=1
    

    # Avoid warnings
    import warnings
    warnings.filterwarnings("ignore")
    
    import seaborn as sns
    import matplotlib.pyplot as plt
    import os
    import datetime
    from os import path
    import numpy as np
    from numpy import matrix as mat
    from scipy.interpolate import interp1d
    from PyTMM.transferMatrix import TransferMatrix,solvePropagation
    import colour

# Creat a new folder to storage output data
#current_path=path.dirname(path.abspath(__file__))
#os.makedirs(current_path+"\\output\\spectrum")
#output_path=current_path+"\\output\\spectrum"

# Define default folder path
    #color_default_folder_path=r"X:\Results"
    spectrum_default_folder_path=r"X:\ExSitu"
    

    recipe_id=text1
    side12=text2
    if side12=="2-side":
        coefficient=10.0
    else:
        coefficient=1
    #input_carrier_id=int(text3)
    
   
    
    
    
    RE_folder=r"C:\Reverse"
    layer_Thickness="\\InitalThickness.xlsx"
    side1spectrum="\\side1spectrum1.csv"
    side1layer_Thickness="\\side1InitalThickness.xlsx"
    Layerthickness=pd.read_excel(RE_folder+layer_Thickness,sheet_name="Sheet1")
    Layerthickness1=pd.read_excel(RE_folder+side1layer_Thickness,sheet_name="Sheet1")
    # if side12=="2-side":
    if recipe_id == "AR1.0" or recipe_id == "AR1.0P":
        layer_n_k_filename="\\AR 1.0 Single layer n&k values.xlsx"
        ideal_exsitu_difference_filename="\\Theory_Actual_AR_1.0_Spectrum.csv"
    if recipe_id == "AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
        layer_n_k_filename="\\AR 2.1 Single layer n&k values.xlsx"
        ideal_exsitu_difference_filename="\\Theory_Actual_AR_2.1_Spectrum.csv"
    if recipe_id == "AR1.1":
        layer_n_k_filename="\\AR 1.1 Single layer n&k values.xlsx"
        ideal_exsitu_difference_filename="\\Theory_Actual_AR_1.1_Spectrum.csv"
    

    output_folder_name='Simulation'
    
    # Creat a new folder to storage output data
    current_path=r"C:\Reverse1"
    
    from pathlib import Path
    '''
    path1=Path("C:\\Reverse1\\")
    if path1.exists():
        your_want_rm_path = "C:\\Reverse1\\"
        #shutil.rmtree(your_want_rm_path)
    '''
    #dir1 = current_path+"\\%s\\spectrum"%(output_folder_name)
    dir1 = current_path+"\\"+(output_folder_name)
    if os.path.exists(dir1):
        shutil.rmtree(dir1)
    os.makedirs(dir1)
    
    os.makedirs(current_path+"\\%s\\spectrum"%(output_folder_name))
    output_path=current_path+"\\%s\\spectrum"%(output_folder_name)
    
    # AR 1.0 design layer thickness
    # based on MFA2 AR Ex situ reference spectrum using macleod RE below layer thickness
    
    #从界面接受
    #从文件中读取
 


    
    correc=0
    if values['ETC']=="AR ETC":
        ETC=1
    if values['ETC']=="only AR":
        ETC=0
    if side12=="2-side":
        ETCTHIC=float(values["ETCThic"])
    if side12=="1-side":
        ETCTHIC=float(values["ETCThic1s"])
    coefficient=10.0
    conve =int(values['Iter'])# 测试sphere3000的时候应该为0 不进行反算
    #input_carrier_id=int(text3)
    wavelength_lower=int(values['wavestart'])
    wavelength_uper=int(values['waveend'])
    steplength=10
    totalength1side=int((wavelength_uper-wavelength_lower)/steplength)+1
    wavelength_range1side=np.linspace(wavelength_lower,wavelength_uper,totalength1side)
    if ETC==1:
        wavelength_lower=400
        wavelength_uper=700
    totalength=int((wavelength_uper-wavelength_lower)/steplength)+1
       
    BM=0
    VAnoindex=0
    BMnoindex=1



    
    # define screen print function
    def printlog(info):
        nowtime=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print("\n"+"=================="*1+"%s"%(nowtime)+"=================="*1)
        print(info+"...\n\n")
        
    ################################ Step 1 ################################
        
    # Ex situ measure total 12 points need 25s, so we just need input
    # point 1 time data
    wavelength_range=np.linspace(wavelength_lower,wavelength_uper,totalength)
    wavelength_rangeX=np.linspace(400,700,31)
    
    if recipe_id == "AR1.1" or recipe_id == "AR1.0" or recipe_id == "AR1.0P":   
        GG3I=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="GG2320-10avg-302974 380-780nm")
        #GG3["Refractive Index"]+=float(values["R0Corr"])
        RDP_1=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP1-191220")
        RDP_2=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP2-191220")
        RDP_3=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP3-191220")
        RDP_4=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP4-191220")
        RDP_5=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP5-191220")
        RDP_6=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP6-191220")
        RDP_7_8=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP7-8-191220")         
        if ETC==1:
            RDP_9=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP7-8-191220")       
    if recipe_id == "AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
        GG3I=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="GG2320-10avg-302974 380-780nm")
        #GG3["Refractive Index"]+=float(values["R0Corr"])
        RDP_1=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP1-191220")
        RDP_2=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP2-191220")
        RDP_3=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP3-191220")
        RDP_4=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP4 and 6 -191220")
        RDP_7_8=pd.read_excel(RE_folder+layer_n_k_filename,sheet_name="RDP7-8-191220")    
      # GG3 substrate
    #CM700D插值用的数据     
  
    
    lm_layer_thickness_dict=dict()
    optimize_spectrum=[]
    optimize_columns=["Wavelength"]
    LM_spectrum=[]
    #----------------------------LM--------------------------------#
    
    
    # zISTS=[]
    # for kk in range(0,len(GG3_n)):
    #     zISTS.append(GG3_n[kk])
    
    # RDP 1
    f_n,f_k=cubic_interpolate(GG3I["Wavelength"],GG3I["Refractive Index"],GG3I["Extinction Coefficient"])
    GG3BM_n=f_n(wavelength_range)
    
    f_n,f_k=cubic_interpolate(RDP_1["Wavelength"],RDP_1["Refractive Index"],RDP_1["Extinction Coefficient"])
    RDP_1_n=f_n(wavelength_range)
    
    # RDP 2
    
    f_n,f_k=cubic_interpolate(RDP_2["Wavelength"],RDP_2["Refractive Index"],RDP_2["Extinction Coefficient"])
    RDP_2_n=f_n(wavelength_range)
    
    # RDP 3
    
    f_n,f_k=cubic_interpolate(RDP_3["Wavelength"],RDP_3["Refractive Index"],RDP_3["Extinction Coefficient"])
    RDP_3_n=f_n(wavelength_range)
    
    
    # RDP 4
       
    f_n,f_k=cubic_interpolate(RDP_4["Wavelength"],RDP_4["Refractive Index"],RDP_4["Extinction Coefficient"])
    RDP_4_n=f_n(wavelength_range)
    
    # RDP 5
    if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
        f_n,f_k=cubic_interpolate(RDP_5["Wavelength"],RDP_5["Refractive Index"],RDP_5["Extinction Coefficient"])
        RDP_5_n=f_n(wavelength_range)
    
    # RDP 6
    
    if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
        f_n,f_k=cubic_interpolate(RDP_6["Wavelength"],RDP_6["Refractive Index"],RDP_6["Extinction Coefficient"])
        RDP_6_n=f_n(wavelength_range)
    
    # RDP 7+8
    
    f_n,f_k=cubic_interpolate(RDP_7_8["Wavelength"],RDP_7_8["Refractive Index"],RDP_7_8["Extinction Coefficient"])
    RDP_7_8_n=f_n(wavelength_range)
    # Code start time
    if ETC==1 and recipe_id == "AR1.1":
        f_n,f_k=cubic_interpolate(RDP_9["Wavelength"],RDP_9["Refractive Index"],RDP_9["Extinction Coefficient"])
        RDP_9_n=f_n(wavelength_range)
    start_time=datetime.datetime.now()
    
    
    
    
    
    
    window.Element('progbar').update_bar(1)
    plt.figure()

      
    #Exitstui 插值用的
    # wavelength_range1=np.linspace(400,700,100)


    #读进来VA区域没有镀膜的光谱数据
    VAnanAR_all=pd.read_csv(values['Browse'])
    VAnanAR=np.transpose(VAnanAR_all.iloc[VAnoindex,10:40])
    new_index=range(0,30)
    VAnanAR.index=new_index
    VAnanAR=VAnanAR.loc[:14]._append(pd.Series(VAnanAR_all.iloc[VAnoindex,5],index=[14+0.5]))._append(VAnanAR.loc[14+1:])
    VAnanAR=VAnanAR.reset_index(drop=True)
    new_index=range(400,701,10)
    VAnanAR.index=new_index


    VAnanAR_cubic=cubic_interpolate_R(VAnanAR.index.tolist(),VAnanAR[:31])
    VAnoAR_data=VAnanAR_cubic(wavelength_range)
    VAnoAR_d=np.vstack((wavelength_range,VAnoAR_data))
    VAnoAR=pd.DataFrame(data=VAnoAR_d.T,columns=["Wavelength","R"])
   
    BMnanAR=np.transpose(VAnanAR_all.iloc[BMnoindex,10:40])
    new_index=range(0,30)
    BMnanAR.index=new_index
    BMnanAR=BMnanAR.loc[:14]._append(pd.Series(VAnanAR_all.iloc[BMnoindex,5],index=[14+0.5]))._append(BMnanAR.loc[14+1:])
    BMnanAR=BMnanAR.reset_index(drop=True)
    new_index=range(400,701,10)
    BMnanAR.index=new_index


    BMnanAR_cubic=cubic_interpolate_R(BMnanAR.index.tolist(),BMnanAR[:31])
    BMnoAR_data=BMnanAR_cubic(wavelength_range)
    BMnoAR_d=np.vstack((wavelength_range,BMnoAR_data))
    BMnoAR=pd.DataFrame(data=BMnoAR_d.T,columns=["Wavelength","R"])

        
    if event =='Run': 
        str3=values['Browse0'].split('/')[-3]
        str1all=values['Browse0'].split('/')[-1]
        str1=str1all.split('.')[0]
        LMfilename="C:\\LM\\"+str3+str1+'.xlsx'
        # if recipe_id == "AR1.1":
        #     layer_n_k_filename="\\AR 1.1 Single layer n&k values.xlsx"
        #     ideal_exsitu_difference_filename="\\Theory_Actual_AR_1.1_Spectrum.csv"
        VABM_Specturm=pd.read_csv(values['Browse0'])  
        if int(values['Fixpoi'])>=0:
            startindex=int(values['Fixpoi'])
            endindex=int(values['Fixpoi'])+1
        else:
            startindex=0
            endindex=VABM_Specturm.shape[0]
        for VBindex in range(startindex,endindex):
            VA_Specturm=np.transpose(VABM_Specturm.iloc[VBindex,10:40])
            new_index=range(0,30)
            VA_Specturm.index=new_index
            VA_Specturm=VA_Specturm.loc[:14]._append(pd.Series(VABM_Specturm.iloc[VBindex,5],index=[14+0.5]))._append(VA_Specturm.loc[14+1:])
            VA_Specturm=VA_Specturm.reset_index(drop=True)
            new_index=range(400,701,10)
            VA_Specturm.index=new_index
            # if side12=="1-side":
            #     VA_Specturm=VA_Specturm[:31]/100
            #     VA_Specturm=((VA_Specturm-VAnanAR)/(1-2*VAnanAR+VAnanAR*VA_Specturm))*100
    
            VA_Specturm_cubic=cubic_interpolate_R(VA_Specturm.index.tolist(),VA_Specturm[:31])
            VA_Specturm_data=VA_Specturm_cubic(wavelength_range)
            VA_Specturm_d=np.vstack((wavelength_range,VA_Specturm_data))
            VASpecturm=pd.DataFrame(data=VA_Specturm_d.T,columns=["Wavelength","R"])
            
           
            
            if VABM_Specturm.loc[VBindex,'L*(D65)']>20:
                BM=0
            else:
                BM=1
        
            if values['ETC']=="AR ETC" and BM==0:
                LayerthicknessVA=pd.read_excel("C:\\Reverse\\RE\\VA layerthicknee"+str(int(values['Fixpoi']))+".xlsx",sheet_name="Sheet1")
            
         
            #  measure_spectrum_cubic=cubic_interpolate_R(measure_spectrum_data["Wavelength"],measure_spectrum_data[measure_column])
            #  measure_spectrum=measure_spectrum_cubic(wavelength_range1)
             
            # RBdata=pd.read_csv("C:\\Reverse1\\20220323171433\\spectrum\\RBR.csv")
    
            # if recipe_id == "AR1.1":
            #     layer_n_k_filename="\\AR 1.1 Single layer n&k values.xlsx"
            #     ideal_exsitu_difference_filename="\\Theory_Actual_AR_1.1_Spectrum.csv"
                
    
    
            BM_Specturm=np.transpose(VABM_Specturm.iloc[VBindex,10:40])
            new_index=range(0,30)
            BM_Specturm.index=new_index
            BM_Specturm=BM_Specturm.loc[:14]._append(pd.Series(VABM_Specturm.iloc[VBindex,5],index=[14+0.5]))._append(BM_Specturm.loc[14+1:])
            BM_Specturm=BM_Specturm.reset_index(drop=True)
            new_index=range(400,701,10)
            BM_Specturm.index=new_index
            # if side12=="1-side":
            #     BM_Specturm=BM_Specturm[:31]/100
            #     BM_Specturm=((BM_Specturm-RB_data1)/(1-2*RB_data1+RB_data1*BM_Specturm))*100
    
            BM_Specturm_cubic=cubic_interpolate_R(BM_Specturm.index.tolist(),BM_Specturm[:31])
            BM_Specturm_data=BM_Specturm_cubic(wavelength_range)
            BM_Specturm_d=np.vstack((wavelength_range,BM_Specturm_data))
            BMSpecturm=pd.DataFrame(data=BM_Specturm_d.T,columns=["Wavelength","R"])
            #这里是不是应该是RB
            R0_data=VAnoAR.loc[:,'R']*(100/(200-VAnoAR.loc[:,'R']))
            RB_1side=BMnoAR.loc[:,'R']-R0_data
            BMSpectrum1side=pd.DataFrame()
            for k in range(len(BMSpecturm)):
                BMSpectrum1side.loc[k,'R']=(BMSpecturm.loc[k,'R']/RB_1side[k]-1)/(1+(1-RB_1side[k])**2/RB_1side[k])
            if values['ETC']=="AR ETC" and BM==1:
                LayerthicknessBM=pd.read_excel("C:\\Reverse\\RE\\BM layerthicknee"+str(int(values['Fixpoi']))+".xlsx",sheet_name="Sheet1")
        
          
        
            if recipe_id == "AR1.1":
                
                RDP_1_d  =Layerthickness.iloc[0,3]
                RDP_2_d  =Layerthickness.iloc[1,3] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,3] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,3] #38.1372# 38.00
                RDP_5_d  =Layerthickness.iloc[4,3] #25.7884# 26.45
                RDP_6_d  =Layerthickness.iloc[5,3] #34.6991# 33.25
                RDP_7_8_d =Layerthickness.iloc[6,3] #95.1257# 95.46
           
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessVA.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessVA.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessVA.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessBM.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessBM.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessBM.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
            if recipe_id == "AR1.3":

                RDP_1_d  =Layerthickness.iloc[0,1]
                RDP_2_d  =Layerthickness.iloc[1,1] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,1] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,1] #38.1372# 38.00
                RDP_7_8_d =Layerthickness.iloc[4,1] #95.1257# 95.46
                
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessVA.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessBM.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
    
            if recipe_id == "AR4.1":

                RDP_1_d  =Layerthickness.iloc[0,4]
                RDP_2_d  =Layerthickness.iloc[1,4] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,4] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,4] #38.1372# 38.00
                RDP_7_8_d =Layerthickness.iloc[4,4] #95.1257# 95.46
                
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessVA.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessBM.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0#95.1257# 95.46
                    conve=0
            if recipe_id == "AR4.0":

                RDP_1_d  =Layerthickness.iloc[0,6]
                RDP_2_d  =Layerthickness.iloc[1,6] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,6] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,6] #38.1372# 38.00
                RDP_7_8_d =Layerthickness.iloc[4,6] #95.1257# 95.46
                
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessVA.iloc[4,1]+ETCTHIC#95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessBM.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0#95.1257# 95.46
                    conve=0

            if recipe_id == "AR1.0":
                RDP_1_d  =Layerthickness.iloc[0,2]
                RDP_2_d  =Layerthickness.iloc[1,2] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,2] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,2] #38.1372# 38.00
                RDP_5_d  =Layerthickness.iloc[4,2] #25.7884# 26.45
                RDP_6_d  =Layerthickness.iloc[5,2] #34.6991# 33.25
                RDP_7_8_d =Layerthickness.iloc[6,2] #95.1257# 95.46
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessVA.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessVA.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessVA.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessBM.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessBM.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessBM.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
            
            if recipe_id == "AR2.1":

                RDP_1_d  =Layerthickness.iloc[0,7]
                RDP_2_d  =Layerthickness.iloc[1,7] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,7] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,7] #38.1372# 38.00
                RDP_7_8_d =Layerthickness.iloc[4,7] #95.1257# 95.46
                
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessVA.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_7_8_d =LayerthicknessBM.iloc[4,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
    
            if recipe_id == "AR1.0P":
                RDP_1_d  =Layerthickness.iloc[0,8]
                RDP_2_d  =Layerthickness.iloc[1,8] #12.55# 11.82
                RDP_3_d  =Layerthickness.iloc[2,8] #49.9277# 49.24
                RDP_4_d  =Layerthickness.iloc[3,8] #38.1372# 38.00
                RDP_5_d  =Layerthickness.iloc[4,8] #25.7884# 26.45
                RDP_6_d  =Layerthickness.iloc[5,8] #34.6991# 33.25
                RDP_7_8_d =Layerthickness.iloc[6,8] #95.1257# 95.46
           
                if ETC==1 and BM==0:
                    RDP_2_d  =LayerthicknessVA.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessVA.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessVA.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessVA.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessVA.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessVA.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
                if ETC==1 and BM==1:
                    RDP_2_d  =LayerthicknessBM.iloc[1,1] #12.55# 11.82
                    RDP_3_d  =LayerthicknessBM.iloc[2,1] #49.9277# 49.24
                    RDP_4_d  =LayerthicknessBM.iloc[3,1] #38.1372# 38.00
                    RDP_5_d  =LayerthicknessBM.iloc[4,1] #25.7884# 26.45
                    RDP_6_d  =LayerthicknessBM.iloc[5,1] #34.6991# 33.25
                    RDP_7_8_d =LayerthicknessBM.iloc[6,1]+ETCTHIC #95.1257# 95.46
                    RDP_9_d =0 #95.1257# 95.46
                    conve=0
            RORBData=pd.read_excel("C:\\Reverse\\R0RBData.xlsx")#len(RORBData)
            
            def task(s,e,BM01,ETCthickness,IterationCo):
                RTEMP=RORBData.loc[s:e,:]
                msefinaList=[]
                xklist=[]
                for exl in range(len(RTEMP)):
                    BM=BM01
                    conve=IterationCo
                    v=0.5
                    u=RTEMP.iloc[exl,0]
                    correRB=RTEMP.iloc[exl,2]
                    correR0=RTEMP.iloc[exl,1]
                    iuin=RTEMP.index[exl]
                    GG3=GG3I["Refractive Index"]+correR0
                    f_n,f_k=cubic_interpolate(GG3I["Wavelength"],GG3,GG3I["Extinction Coefficient"])
                    GG3_n=f_n(wavelength_range)
    
                    RB_data=BMnoAR.loc[:,'R']-VAnoAR.loc[:,'R']/2+correRB
                    # RB_data=BMnoAR.loc[:,'R']-VAnoAR.loc[:,'R']*(100/(200-VAnoAR.loc[:,'R']))
                    RB_d=np.vstack((wavelength_range,RB_data))
                    RB=pd.DataFrame(data=RB_d.T,columns=["Wavelength","R"])
                    #R0=pd.DataFrame(data=R0_d.T,columns=["Wavelength","R"])
                    
                    
                    if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
                        n_layers=6
                    if recipe_id == "AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                        n_layers=4
                    
                    # Spectrum library recommend layer thickness used as LM method input
                    if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
                        xk=mat([[RDP_2_d],
                                [RDP_3_d],
                                [RDP_4_d],
                                [RDP_5_d],
                                [RDP_6_d],
                                [RDP_7_8_d]])
                        if ETC==1:
                                xk=mat([[RDP_2_d],
                                        [RDP_3_d],
                                        [RDP_4_d],
                                        [RDP_5_d],
                                        [RDP_6_d],
                                        [RDP_7_8_d],
                                        [RDP_9_d]])
                    if recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0": 
                        xk=mat([[RDP_2_d],
                                [RDP_3_d],
                                [RDP_4_d],
                                [RDP_7_8_d]])
                        if ETC==1:
                                xk=mat([[RDP_2_d],
                                        [RDP_3_d],
                                        [RDP_4_d],
                                        [RDP_7_8_d],
                                        [RDP_9_d]])
                    
                    n=len(wavelength_range)
                    J = mat(np.zeros((n,n_layers)))      #雅克比矩阵  
                    fx = mat(np.zeros((n,1)))     # f(x)  100*1  误差  
                    fx_tmp = mat(np.zeros((n,1)))
                    n=len(wavelength_range)  
                    lase_mse = 0  
                    #step=1
                    
                   
                    if BM==1:
                        y = [BMSpecturm.loc[i,"R"] for i in range(totalength)]  
                        y = mat(y)   # 真实的数据也就是测试的数据转变为矩阵形式  
                        R0B = [RB.loc[i,"R"] for i in range(totalength)] 
                    else:
                        y = [VASpecturm.loc[i,"R"] for i in range(totalength)]  
                        y = mat(y)   # 真实的数据也就是测试的数据转变为矩阵形式  
                    
                    
        
                    while (conve):  
                          
                            mse,mse_tmp = 0,0  
                            # step += 1  
                            for i in range(n):  
                                if BM==1:
                                    fx[i] =  ((FuncBM(xk,i,R0B[i]/100,GG3BM_n[i]) - y[0,i]))  # 不能写成  y - Func  ,否则发散 ,乘以的系数还是很重要 
                                else:
                                    fx[i] =  ((Func(xk,i,GG3_n[i]) - y[0,i]))
                                mse += fx[i,0]**2  
                          
                                for j in range(n_layers):  
                                    if BM==1:
                                        J[i,j] = DerivBM(xk,i,j,R0B[i],GG3BM_n[i]) # 数值求导  
                                    else:
                                        J[i,j] = Deriv(xk,i,j,GG3_n[i]) # 数值求导 
                                mse /= n  # 范围约束  
                          
                            H = J.T*J + u*np.eye(n_layers)   # 4*4  
                            #dx1 = abs(-H.I * J.T*fx)        # 注意这里有一个负号，和fx = Func - y的符号要对应  
                            dx = (-H.I * J.T*fx)
                            #fh=dx/abs(dx)
                            #dx=dx1/fh
                            xk_tmp = xk.copy()  
                            '''
                            for ix in range(layercount):
                                if xk_tmp[ix][0]+dx[ix][0]-xk1[ix][0]>xk1[ix][0]*0.1:
                                    dx[ix][0]=xk1[ix][0]*1.1-xk_tmp[ix][0]
                                elif xk_tmp[ix][0]+dx[ix][0]-xk1[ix][0]<xk1[ix][0]*(-0.1):
                                    dx[ix][0]=xk1[ix][0]*0.9-xk_tmp[ix][0]   
                            '''
                            xk_tmp += dx  
                          
                            for j in range(n):  
                                if BM==1:
                                    fx_tmp[j] =  FuncBM(xk_tmp,j,R0B[j]/100,GG3BM_n[j]) - y[0,j] 
                                else:
                                    fx_tmp[j] =  Func(xk_tmp,j,GG3_n[i]) - y[0,j]  
                                mse_tmp += fx_tmp[j,0]**2  
                                mse_tmp /= n  
                          
                            q = (mse - mse_tmp)/((0.5*dx.T*(u*dx - J.T*fx))[0,0])  
                          
                            if q > 0:  
                                s = 1.0/3.0  
                                v =2 
                                mse = mse_tmp  
                                xk = xk_tmp  
                                temp = 1 - pow(2*q-1,n_layers)  
                          
                                if s > temp:  
                                    u = u*s  
                                else:  
                                    u = u*temp  
                            else:  
                                u = u*v  
                                v = 2*v  
                                xk = xk_tmp  
                            if u>100000000000000000000000000000000:
                                break
                            if  abs(mse)<0.0000000000000001: 
                            # if abs(mse)<0.0000000001: 
                                break  
                            # if abs(mse-lase_mse)<0.0000001: 
                            #     break  
                            # if  abs(mse)<0.0000001: #abs(mse-lase_mse)<0.0001: 
                            #     break  
                          
                            lase_mse = mse  # 记录上一个 mse 的位置  
                            conve -= 1  
                    

                    if BM==0:
                        if ETC==0:
                            zVA = [Func(xk,ii,GG3_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                            if recipe_id =="AR1.1" or recipe_id =="AR1.0" or recipe_id == "AR1.0P":
                                xketc=mat([[float(xk[0][0])],
                                        [float(xk[1][0])],
                                        [float(xk[2][0])],
                                        [float(xk[3][0])],
                                        [float(xk[4][0])],
                                        [float(xk[5][0])+ETCthickness]])
                            if recipe_id =="AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                                xketc=mat([[float(xk[0][0])],
                                        [float(xk[1][0])],
                                        [float(xk[2][0])],
                                        [float(xk[3][0])+ETCthickness]])
                            zVAETC = [Func(xketc,ii,GG3_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                        # plt.figure()
                        # plt.plot(wavelength_range,zVA,label="LM recommended spectrum")
                        # plt.plot(wavelength_range,VASpecturm.loc[:,'R'],label="measure spectrum")
                        # ymin, ymax = plt.gca().get_ylim()
                        # xmin, xmax = plt.gca().get_xlim()
                        # plt.text(xmin+0.1, ymin+0.1, "R0="+str(correR0))
                        # plt.text(xmin+0.1, ymin+0.2, "RB="+str(correRB))
                        # if ETC==0:
                        #     plt.plot(wavelength_range,zVAETC,label="WithETC")
                        # plt.xlabel("Wavelength (nm)")
                        # plt.legend(loc="best")
                        # plt.savefig("C:\\Picture3\\reflesh\\Var"+str(iuin)+".jpg") #
                        # if iuin<10:
                        #     plt.savefig("C:\\Picture3\\reflesh\\Var"+"0"+str(iuin)+".jpg") #
                        # if iuin>9:
                        #     plt.savefig("C:\\Picture3\\reflesh\\Var"+str(iuin)+".jpg") #
                        
                    if BM==1:
                        zBM = [FuncBM(xk,ii,R0B[ii]/100,GG3BM_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                        if ETC==0:
                            if recipe_id =="AR1.1" or recipe_id =="AR1.0" or recipe_id == "AR1.0P":
                                xketc=mat([[float(xk[0][0])],
                                        [float(xk[1][0])],
                                        [float(xk[2][0])],
                                        [float(xk[3][0])],
                                        [float(xk[4][0])],
                                        [float(xk[5][0])+ETCthickness]])
                            if recipe_id =="AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                                xketc=mat([[float(xk[0][0])],
                                        [float(xk[1][0])],
                                        [float(xk[2][0])],
                                        [float(xk[3][0])+ETCthickness]])
                            zBMETC = [FuncBM(xketc,ii,R0B[ii]/100,GG3BM_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                        # plt.figure()
                        # plt.plot(wavelength_range,zBM,label="LM recommended spectrum")
                        # plt.plot(wavelength_range,BMSpecturm.loc[:,'R'],label="measure spectrum")
                        # ymin, ymax = plt.gca().get_ylim()
                        # xmin, xmax = plt.gca().get_xlim()
                        # plt.text(xmin+0.1, ymin+0.1, "R0="+str(correR0))
                        # plt.text(xmin+0.1, ymin+0.2, "RB="+str(correRB))
                        # if ETC==0:
                        #     plt.plot(wavelength_range,zBMETC,label="WithETC")
                        # plt.xlabel("Wavelength (nm)")  
                        # plt.legend(loc="best")
                        # if iuin<10:
                        #     plt.savefig("C:\\Picture3\\reflesh\\Var"+"0"+str(iuin)+".jpg") #
                        # if iuin>9:
                        #     plt.savefig("C:\\Picture3\\reflesh\\Var"+str(iuin)+".jpg") #
                    msefinall=0  
                    msefinall0=0
                    if e==0:
                        for i in range(5):
                            if BM==1:
                                deltavalue =((zBM[i][0] - BMSpecturm.loc[i,'R']))
                                msefinall0 += deltavalue 
                            else:
                                deltavalue =((zVA[i][0] - BMSpecturm.loc[i,'R']))
                                msefinall0 += deltavalue 
                        
                        for i in range(n):
                            if BM==1:
                                deltavalue =abs(((zBM[i][0] - BMSpecturm.loc[i,'R'])))
                                msefinall += deltavalue 
                            else:
                                deltavalue =abs(((zVA[i][0] - BMSpecturm.loc[i,'R'])))
                                msefinall += deltavalue 
                    else:
                        for i in range(n):
                            if BM==1:
                                deltavalue =abs(((zBM[i][0] - BMSpecturm.loc[i,'R'])))
                                msefinall += deltavalue 
                            else:
                                deltavalue =abs(((zVA[i][0] - BMSpecturm.loc[i,'R'])))
                                msefinall += deltavalue 
                      
                    msefinaList.append(msefinall)
                    # xklist.append(xk)
                # q.put(msefinaList)
                return msefinaList, msefinall0
            
            
            if ETC==0  and float(values['R0Corr'])==0 and float(values['RBCorr'])==0 :
                Runtimes=int(values['Iter'])
                # RORBData.loc[exl,'MSE']=msefinall
                tasks=[]
                for tai in range(0,30,5):
                    s=tai
                    e=tai+4
                    taskde=joblib.delayed(task)(s,e,BM,ETCTHIC,Runtimes)
                    tasks.append(taskde)
                parallel=joblib.Parallel(n_jobs=6)
                FMSE=parallel(tasks)
            FinalMSE=[]
            # FinalThic=[xkrevese[0]]
            for MS in range(len(FMSE)):
                FinalMSE=FinalMSE+FMSE[MS][0]
                # FinalThic=FinalThic+FMSE[MS][1]
            min_value = min(FinalMSE)
            # for nummm in squares:
            #     print(nummm)
            min_row = FinalMSE.index(min_value)
            # FinalThicGroup=FinalThic[min_row]
            # xk=FinalThicGroup
            if ETC==0:
                conve=int(values['Iter'])
            if ETC==1:
                conve=0
            u=RORBData.loc[min_row,'u']
            v=0.5
            correRB=RORBData.loc[min_row,'RB']
            correR0=RORBData.loc[min_row,'R0']
            if abs(float(values['R0Corr']))>0:
                correR0=float(values['R0Corr'])
            if abs(float(values['RBCorr']))>0:
                correRB=float(values['RBCorr'])
            GG3= GG3I["Refractive Index"]+correR0
            f_n,f_k=cubic_interpolate(GG3I["Wavelength"],GG3,GG3I["Extinction Coefficient"])
            GG3_n=f_n(wavelength_range)
            GG3_X=f_n(wavelength_rangeX)
            if side12=="1-side":
                for i in range(len(GG3_X)):
                    VAnanAR[VAnanAR.index[i]]=((1-GG3_X[i])/(1+GG3_X[i]))**2

            VAnanAR_cubic=cubic_interpolate_R(VAnanAR.index.tolist(),VAnanAR[:31])
            VAnoAR_data=VAnanAR_cubic(wavelength_range)
            VAnoAR_d=np.vstack((wavelength_range,VAnoAR_data))
            VAnoAR=pd.DataFrame(data=VAnoAR_d.T,columns=["Wavelength","R"])
            if side12=="1-side":
                VA_Specturm=VA_Specturm[:31]/100
                VA_Specturm=((VA_Specturm-VAnanAR)/(1-2*VAnanAR+VAnanAR*VA_Specturm))*100
                
            VA_Specturm_cubic=cubic_interpolate_R(VA_Specturm.index.tolist(),VA_Specturm[:31])
            VA_Specturm_data=VA_Specturm_cubic(wavelength_range)
            VA_Specturm_d=np.vstack((wavelength_range,VA_Specturm_data))
            VASpecturm=pd.DataFrame(data=VA_Specturm_d.T,columns=["Wavelength","R"])
            BMnanAR=np.transpose(VAnanAR_all.iloc[BMnoindex,10:40])
            new_index=range(0,30)
            BMnanAR.index=new_index
            BMnanAR=BMnanAR.loc[:14]._append(pd.Series(VAnanAR_all.iloc[BMnoindex,5],index=[14+0.5]))._append(BMnanAR.loc[14+1:])
            BMnanAR=BMnanAR.reset_index(drop=True)
            new_index=range(400,701,10)
            BMnanAR.index=new_index


            BMnanAR_cubic=cubic_interpolate_R(BMnanAR.index.tolist(),BMnanAR[:31])
            BMnoAR_data=BMnanAR_cubic(wavelength_range)
            BMnoAR_d=np.vstack((wavelength_range,BMnoAR_data))
            BMnoAR=pd.DataFrame(data=BMnoAR_d.T,columns=["Wavelength","R"])
            

            
            RB_data=BMnoAR.loc[:,'R']-VAnoAR.loc[:,'R']/2+correRB
            # RB_data=BMnoAR.loc[:,'R']-VAnoAR.loc[:,'R']*(100/(200-VAnoAR.loc[:,'R']))
            RB_d=np.vstack((wavelength_range,RB_data))
            RB=pd.DataFrame(data=RB_d.T,columns=["Wavelength","R"])
            #R0=pd.DataFrame(data=R0_d.T,columns=["Wavelength","R"])
            
           
            
            if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
                n_layers=6
            if recipe_id == "AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                n_layers=4
            
            # Spectrum library recommend layer thickness used as LM method input
            if recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P": 
                xk=mat([[RDP_2_d],
                        [RDP_3_d],
                        [RDP_4_d],
                        [RDP_5_d],
                        [RDP_6_d],
                        [RDP_7_8_d]])
                if ETC==1:
                        xk=mat([[RDP_2_d],
                                [RDP_3_d],
                                [RDP_4_d],
                                [RDP_5_d],
                                [RDP_6_d],
                                [RDP_7_8_d],
                                [RDP_9_d]])
            if recipe_id == "AR1.3" or recipe_id == "AR2.1" or recipe_id == "AR4.1" or recipe_id == "AR4.0": 
                xk=mat([[RDP_2_d],
                        [RDP_3_d],
                        [RDP_4_d],
                        [RDP_7_8_d]])
                if ETC==1:
                        xk=mat([[RDP_2_d],
                                [RDP_3_d],
                                [RDP_4_d],
                                [RDP_7_8_d],
                                [RDP_9_d]])
            
            n=len(wavelength_range)
            J = mat(np.zeros((n,n_layers)))      #雅克比矩阵  
            fx = mat(np.zeros((n,1)))     # f(x)  100*1  误差  
            fx_tmp = mat(np.zeros((n,1)))
            n=len(wavelength_range)  
            lase_mse = 0  
            #step=1
           
            if BM==1:
                y = [BMSpecturm.loc[i,"R"] for i in range(totalength)]  
                y = mat(y)   # 真实的数据也就是测试的数据转变为矩阵形式  
                R0B = [RB.loc[i,"R"] for i in range(totalength)] 
            else:
                y = [VASpecturm.loc[i,"R"] for i in range(totalength)]  
                y = mat(y)   # 真实的数据也就是测试的数据转变为矩阵形式  

            while (conve):  
                  
                    mse,mse_tmp = 0,0  
                    # step += 1  
                    for i in range(n):  
                        if BM==1:
                            fx[i] =  ((FuncBM(xk,i,R0B[i]/100,GG3BM_n[i]) - y[0,i]))  # 不能写成  y - Func  ,否则发散 ,乘以的系数还是很重要 
                        else:
                            fx[i] =  ((Func(xk,i,GG3_n[i]) - y[0,i]))
                        mse += fx[i,0]**2  
                  
                        for j in range(n_layers):  
                            if BM==1:
                                J[i,j] = DerivBM(xk,i,j,R0B[i],GG3BM_n[i]) # 数值求导 
                            else:
                                J[i,j] = Deriv(xk,i,j,GG3_n[i])# 数值求导 
                        mse /= n  # 范围约束  
                  
                    H = J.T*J + u*np.eye(n_layers)   # 4*4  
                    #dx1 = abs(-H.I * J.T*fx)        # 注意这里有一个负号，和fx = Func - y的符号要对应  
                    dx = (-H.I * J.T*fx)
                    #fh=dx/abs(dx)
                    #dx=dx1/fh
                    xk_tmp = xk.copy()  
                    '''
                    for ix in range(layercount):
                        if xk_tmp[ix][0]+dx[ix][0]-xk1[ix][0]>xk1[ix][0]*0.1:
                            dx[ix][0]=xk1[ix][0]*1.1-xk_tmp[ix][0]
                        elif xk_tmp[ix][0]+dx[ix][0]-xk1[ix][0]<xk1[ix][0]*(-0.1):
                            dx[ix][0]=xk1[ix][0]*0.9-xk_tmp[ix][0]   
                    '''
                    xk_tmp += dx  
                  
                    for j in range(n):  
                        if BM==1:
                            fx_tmp[j] =  FuncBM(xk_tmp,j,R0B[j]/100,GG3BM_n[j]) - y[0,j] 
                        else:
                            fx_tmp[j] =  Func(xk_tmp,j,GG3_n[i]) - y[0,j]  
                        mse_tmp += fx_tmp[j,0]**2  
                        mse_tmp /= n  
                  
                    q = (mse - mse_tmp)/((0.5*dx.T*(u*dx - J.T*fx))[0,0])  
                  
                    if q > 0:  
                        s = 1.0/3.0  
                        v =0.5  
                        mse = mse_tmp  
                        xk = xk_tmp  
                        temp = 1 - pow(2*q-1,n_layers)  
                  
                        if s > temp:  
                            u = u*s  
                        else:  
                            u = u*temp  
                    else:  
                        u = u*v  
                        v = 2*v  
                        xk = xk_tmp  
                    if u>100000000000000000000000000000000:
                        break
                    if  abs(mse)<0.0000000000000001: 
                    # if abs(mse)<0.0000000001: 
                        break  
                    # if abs(mse-lase_mse)<0.0000001: 
                    #     break  
                    # if  abs(mse)<0.0000001: #abs(mse-lase_mse)<0.0001: 
                    #     break  
                  
                    lase_mse = mse  # 记录上一个 mse 的位置  
                    conve -= 1  
            
            if BM==0:
                if ETC==0:
                    zVA = [Func(xk,ii,GG3_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                    if recipe_id =="AR1.1" or recipe_id =="AR1.0" or recipe_id == "AR1.0P":
                        xketc=mat([[float(xk[0][0])],
                                [float(xk[1][0])],
                                [float(xk[2][0])],
                                [float(xk[3][0])],
                                [float(xk[4][0])],
                                [float(xk[5][0])+ETCTHIC]])
                    if recipe_id =="AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                        xketc=mat([[float(xk[0][0])],
                                [float(xk[1][0])],
                                [float(xk[2][0])],
                                [float(xk[3][0])+ETCTHIC]])
                    zVAETC = [Func(xketc,ii,GG3_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                if ETC==1:
                    zVA = [Func(xk,ii,GG3_n[ii]) for ii in range(n)] #用拟合好的参数画图 
            if BM==1:
                zBM = [FuncBM(xk,ii,R0B[ii]/100,GG3BM_n[ii]) for ii in range(n)] #用拟合好的参数画图 
                if ETC==0:
                    if recipe_id =="AR1.1" or recipe_id =="AR1.0" or recipe_id == "AR1.0P":
                        xketc=mat([[float(xk[0][0])],
                                [float(xk[1][0])],
                                [float(xk[2][0])],
                                [float(xk[3][0])],
                                [float(xk[4][0])],
                                [float(xk[5][0])+ETCTHIC]])
                    if recipe_id =="AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1":
                        xketc=mat([[float(xk[0][0])],
                                [float(xk[1][0])],
                                [float(xk[2][0])],
                                [float(xk[3][0])+ETCTHIC]])
                    zBMETC = [FuncBM(xketc,ii,R0B[ii]/100,GG3BM_n[ii]) for ii in range(n)] #用拟合好的参数画图 
            
            if ETC==0 and (recipe_id == "AR1.0" or  recipe_id == "AR1.1" or recipe_id == "AR1.0P"):
                xk=np.array(xk)
                lm_layer_thickness_dict=dict()
                lm_layer_thickness_dict['Layer']=['Layer1',
                                       'Layer2',
                                       'Layer3',
                                       'Layer4',
                                       'Layer5',
                                       'Layer6',
                                       'Layer7']
                lm_layer_thickness_dict['AR1.1']=[RDP_1_d,
                                       xk[0][0],
                                       xk[1][0],
                                       xk[2][0],
                                       xk[3][0],
                                       xk[4][0],
                                       xk[5][0]]
                df = pd.DataFrame(lm_layer_thickness_dict)
                window.Element('D1DES').Update(RDP_1_d)
                window.Element('D2DES').Update(RDP_2_d)
                window.Element('D3DES').Update(RDP_3_d)
                window.Element('D4DES').Update(RDP_4_d)
                window.Element('D5DES').Update(RDP_5_d)
                window.Element('D6DES').Update(RDP_6_d)
                window.Element('D7DES').Update(RDP_7_8_d)
                window.Element('D1REV').Update(RDP_1_d)
                window.Element('D2REV').Update(xk[0][0])
                window.Element('D3REV').Update(xk[1][0])
                window.Element('D4REV').Update(xk[2][0])
                window.Element('D5REV').Update(xk[3][0])
                window.Element('D6REV').Update(xk[4][0])
                window.Element('D7REV').Update(xk[5][0])
                
                
                # 写入CSV文件
                if BM==1:
                    if int(values['Fixpoi'])>=0:
                        ZBM700=pd.DataFrame({'700D-BM': BMSpecturm.loc[:,'R']})
                        ZBMR=pd.DataFrame(data=zBM,columns=['R-BM'])
                        ZBM=pd.concat([ZBM700,ZBMR],axis=1)
                        # ZBM = pd.DataFrame({'col1': BMSpecturm.loc[:,'R'], 'col2': zBM})
                        ZBM.to_excel("C:\\Reverse\\RE\\ZBM"+str(int(values['Fixpoi']))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\BM layerthicknee"+str(int(values['Fixpoi']))+".xlsx", index=False)
                    else:
                        ZBM700=pd.DataFrame({'700D-BM': BMSpecturm.loc[:,'R']})
                        ZBMR=pd.DataFrame(data=zBM,columns=['R-BM'])
                        ZBM=pd.concat([ZBM700,ZBMR],axis=1)
                        # ZBM = pd.DataFrame({'col1': BMSpecturm.loc[:,'R'], 'col2': zBM})
                        ZBM.to_excel("C:\\Reverse\\RE\\ZBM"+str(int(VBindex))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\BM layerthicknee"+str(int(VBindex))+".xlsx", index=False)
                else:
                    if int(values['Fixpoi'])>=0:
                        ZVA700=pd.DataFrame({'700D-VA': VASpecturm.loc[:,'R']})
                        ZVAR=pd.DataFrame(data=zVA,columns=['R-VA'])
                        ZVA=pd.concat([ZVA700,ZVAR],axis=1)
                        ZVA.to_excel("C:\\Reverse\\RE\\ZVA"+str(int(values['Fixpoi']))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\VA layerthicknee"+str(int(values['Fixpoi']))+".xlsx", index=False)
                    else:
                        ZVA700=pd.DataFrame({'700D-VA': VASpecturm.loc[:,'R']})
                        ZVAR=pd.DataFrame(data=zVA,columns=['R-VA'])
                        ZVA=pd.concat([ZVA,ZVA700,ZVAR],axis=1)
                        ZVA.to_excel("C:\\Reverse\\RE\\ZVA"+str(int(VBindex))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\VA layerthicknee"+str(int(VBindex))+".xlsx", index=False)
            if ETC==0 and (recipe_id == "AR1.3" or recipe_id == "AR4.1" or recipe_id == "AR4.0" or recipe_id == "AR2.1"):
                xk=np.array(xk)
                lm_layer_thickness_dict=dict()
                lm_layer_thickness_dict['Layer']=['Layer1',
                                       'Layer2',
                                       'Layer3',
                                       'Layer4',
                                       'Layer7']
                lm_layer_thickness_dict['AR1.1']=[RDP_1_d,
                                       xk[0][0],
                                       xk[1][0],
                                       xk[2][0],
                                       xk[3][0]]
                df = pd.DataFrame(lm_layer_thickness_dict)
                window.Element('D1DES').Update(RDP_1_d)
                window.Element('D2DES').Update(RDP_2_d)
                window.Element('D3DES').Update(RDP_3_d)
                window.Element('D4DES').Update(RDP_4_d)
                window.Element('D5DES').Update(RDP_7_8_d)
                window.Element('D1REV').Update(RDP_1_d)
                window.Element('D2REV').Update(xk[0][0])
                window.Element('D3REV').Update(xk[1][0])
                window.Element('D4REV').Update(xk[2][0])
                window.Element('D5REV').Update(xk[3][0])
                
                # 写入CSV文件
                if BM==1:
                    if int(values['Fixpoi'])>=0:
                        ZBM700=pd.DataFrame({'700D-BM': BMSpecturm.loc[:,'R']})
                        ZBMR=pd.DataFrame(data=zBM,columns=['R-BM'])
                        ZBM=pd.concat([ZBM700,ZBMR],axis=1)
                        # ZBM = pd.DataFrame({'col1': BMSpecturm.loc[:,'R'], 'col2': zBM})
                        ZBM.to_excel("C:\\Reverse\\RE\\ZBM"+str(int(values['Fixpoi']))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\BM layerthicknee"+str(int(values['Fixpoi']))+".xlsx", index=False)
                    else:
                        ZBM700=pd.DataFrame({'700D-BM': BMSpecturm.loc[:,'R']})
                        ZBMR=pd.DataFrame(data=zBM,columns=['R-BM'])
                        ZBM=pd.concat([ZBM700,ZBMR],axis=1)
                        # ZBM = pd.DataFrame({'col1': BMSpecturm.loc[:,'R'], 'col2': zBM})
                        ZBM.to_excel("C:\\Reverse\\RE\\ZBM"+str(int(VBindex))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\BM layerthicknee"+str(int(VBindex))+".xlsx", index=False)
                else:
                    if int(values['Fixpoi'])>=0:
                        ZVA700=pd.DataFrame({'700D-VA': VASpecturm.loc[:,'R']})
                        ZVAR=pd.DataFrame(data=zVA,columns=['R-VA'])
                        ZVA=pd.concat([ZVA700,ZVAR],axis=1)
                        ZVA.to_excel("C:\\Reverse\\RE\\ZVA"+str(int(values['Fixpoi']))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\VA layerthicknee"+str(int(values['Fixpoi']))+".xlsx", index=False)
                    else:
                        ZVA700=pd.DataFrame({'700D-VA': VASpecturm.loc[:,'R']})
                        ZVAR=pd.DataFrame(data=zVA,columns=['R-VA'])
                        ZVA=pd.concat([ZVA,ZVA700,ZVAR],axis=1)
                        ZVA.to_excel("C:\\Reverse\\RE\\ZVA"+str(int(VBindex))+".xlsx",index=False)
                        df.to_excel("C:\\Reverse\\RE\\VA layerthicknee"+str(int(VBindex))+".xlsx", index=False)
                
            imagepath3="C:\\Picture3\\VABMAR1.1.jpg"  
            plt.figure()
            if BM==0:
                plt.plot(wavelength_range,zVA,label="LM recommended spectrum")
                plt.plot(wavelength_range,VASpecturm.loc[:,'R'],label="measure spectrum")
                ymin, ymax = plt.gca().get_ylim()
                xmin, xmax = plt.gca().get_xlim()
                plt.text(460, ymin+0.05, "R0="+str(correR0))
                plt.text(460, ymin+0.08, "RB="+str(correRB))
                if ETC==0:
                    plt.plot(wavelength_range,zVAETC,label="WithETC")
                plt.xlabel("Wavelength (nm)")
            if BM==1:
                plt.plot(wavelength_range,zBM,label="LM recommended spectrum")
                plt.plot(wavelength_range,BMSpecturm.loc[:,'R'],label="measure spectrum")
                ymin, ymax = plt.gca().get_ylim()
                xmin, xmax = plt.gca().get_xlim()
                plt.text(460, ymin+0.05, "R0="+str(correR0))
                plt.text(460, ymin+0.08, "RB="+str(correRB))
                if ETC==0:
                    plt.plot(wavelength_range,zBMETC,label="WithETC")
                plt.xlabel("Wavelength (nm)")   
            # if side12=="1-side":
            #     plt.ylim(0,1.2)
            if ETC==1:
                plt.ylabel("2-sided R ETC")
            else:
                plt.ylabel("2-sided R")
            plt.xlim(380,710)
            # plt.ylim(4,8)
            plt.legend(loc="best")
            plt.savefig(imagepath3) #
            imagepath4="C:\\Picture3\\BM1SIDE.jpg"  
            plt.figure()
            if BM==1:
                if ETC==1:
                    wavelength_range1side=np.linspace(400,700,31)
                    plt.plot(wavelength_range1side,BMSpectrum1side.loc[:,'R'])
                if ETC!=1:
                    plt.plot(wavelength_range1side,BMSpectrum1side.loc[:,'R'])
                plt.hlines(y=0.3, xmin=wavelength_range1side[0], xmax=wavelength_range1side[-1], color='red')
                plt.hlines(y=0.2, xmin=wavelength_range1side[0], xmax=wavelength_range1side[-1], color='g')
                plt.ylim(0,1)
                plt.xlabel("Wavelength (nm)")   
                plt.ylabel("1-sided R")
            plt.legend(loc="best")
            plt.savefig(imagepath4) #
            Fixpos=int(values['Fixpoi'])
            if BM==1:
                spectrumBM=dict()
                spectrumBMETC=dict()
                spectrumBM_Measure=dict()
                BMready=[]
                BMreadyETC=[]
                for BM in range(len(zBM)):
                    BMready.append(zBM[BM][0])
                if ETC==0:    
                    for BMETC in range(len(zBMETC)):
                        BMreadyETC.append(zBMETC[BMETC][0])
                    
                totalength10=int((wavelength_uper-wavelength_lower)/10)+1
                wavelength_range1=np.linspace(wavelength_lower,wavelength_uper,totalength10)
                f_r=cubic_interpolate_R(wavelength_range,BMready)
                normal_spec=f_r(wavelength_range1)
                for i,j in zip(wavelength_range1,normal_spec):
                    spectrumBM[i]=j/100
                if ETC==0:    
                    f_r=cubic_interpolate_R(wavelength_range,BMreadyETC)
                    normal_specETC=f_r(wavelength_range1)
                    for i,j in zip(wavelength_range1,normal_specETC):
                        spectrumBMETC[i]=j/100
                    
                f_r=cubic_interpolate_R(wavelength_range,BMSpecturm.loc[:,'R'])
                normal_specmeas=f_r(wavelength_range1)  
                for i,j in zip(wavelength_range1,normal_specmeas):
                    spectrumBM_Measure[i]=j/100
                sdBM=colour.SpectralDistribution(spectrumBM,name="Sample1")
                sdBMmeasure=colour.SpectralDistribution(spectrumBM_Measure,name="Sample2")
                if ETC==0: 
                    sdBMETC=colour.SpectralDistribution(spectrumBMETC,name="Sample3")
                #plot_single_sd(sd)
                # 将光谱转换成Tristimulus Values
                # CIE 1964 10 Degree Standard Observer
                cmfs=colour.colorimetry.MSDS_CMFS_STANDARD_OBSERVER['CIE 1964 10 Degree Standard Observer']
                illuminant=colour.SDS_ILLUMINANTS["D65"]
                XYZ=colour.sd_to_XYZ(sdBM,cmfs,illuminant)
                print("LMRe-XYZ",XYZ)
                Lab=colour.XYZ_to_Lab(XYZ/100)
                print("LMRe-Lab",Lab)
                # Calculating the sample spectral distribution *CIE XYZ* tristimulus values
                XYZ_Measure=colour.sd_to_XYZ(sdBMmeasure,cmfs,illuminant)
                print("700D-XYZ",XYZ_Measure)
                Lab_Measure=colour.XYZ_to_Lab(XYZ_Measure/100)
                print("700D-Lab",Lab_Measure)     
                if ETC==1: 
                    
                    # Calculating the sample spectral distribution *CIE XYZ* tristimulus values
                    XYZ=colour.sd_to_XYZ(sdBM,cmfs,illuminant)
                    print("ETC -XYZ",XYZ)
                    
                    Lab=colour.XYZ_to_Lab(XYZ/100)
                    print("ETC -Lab",Lab)
                    LM_result=pd.DataFrame()
                    if os.path.isfile(LMfilename):
                        # 文件存在，我们可以读取它
                        LM_result = pd.read_excel(LMfilename)
                    else:
                        # 文件不存在，我们可以创建一个新的Excel文件
                        LM_result.to_excel(LMfilename)  # 将DataFrame保存到Excel文件中
                    # LM_result=pd.read_excel("C:\\LM\\LM.xlsx",sheet_name="Sheet1")
                    LM_result.loc[Fixpos,'Y550']=zBM[15][0]
                    LM_result.loc[Fixpos,'Ymax']=max(zBM[15:-1])[0]
                    LM_result.loc[Fixpos,'Y']=XYZ[1]
                    LM_result.loc[Fixpos,'L']=Lab[0]
                    LM_result.loc[Fixpos,'a']=Lab[1]
                    LM_result.loc[Fixpos,'b']=Lab[2]
                    LM_result.to_excel(LMfilename,sheet_name="Sheet1",index=False)
                    
            if BM==0:
                spectrumVA=dict()
                spectrumVAETC=dict()
                spectrumVA_Measure=dict()
                VAready=[]
                VAETCready=[]
                for VA in range(len(zVA)):
                    VAready.append(zVA[VA][0])
                if ETC==0:  
                    for ETCVA in range(len(zVAETC)):
                        VAETCready.append(zVAETC[ETCVA][0])
                    
                totalength10=int((wavelength_uper-wavelength_lower)/10)+1
                wavelength_range1=np.linspace(wavelength_lower,wavelength_uper,totalength10)
    
                f_r=cubic_interpolate_R(wavelength_range,VAready)
                normal_spec=f_r(wavelength_range1)
                for i,j in zip(wavelength_range1,normal_spec):
                    spectrumVA[i]=j/100
                    
                f_r=cubic_interpolate_R(wavelength_range,VASpecturm.loc[:,'R'])
                normal_specmeas=f_r(wavelength_range1)  
    
                for i,j in zip(wavelength_range1,normal_specmeas):
                    spectrumVA_Measure[i]=j/100
                if ETC==0:     
                    f_r=cubic_interpolate_R(wavelength_range,VAETCready)
                    normal_specmeasETC=f_r(wavelength_range1)  
                    
                    for i,j in zip(wavelength_range1,normal_specmeasETC):
                        spectrumVAETC[i]=j/100
                    
                sdVA=colour.SpectralDistribution(spectrumVA,name="Sample1")
                sdVAmeasure=colour.SpectralDistribution(spectrumVA_Measure,name="Sample2")
                if ETC==0:  
                    sdVAETC=colour.SpectralDistribution(spectrumVAETC,name="Sample3")
                #plot_single_sd(sd)
    
                # 将光谱转换成Tristimulus Values
                # CIE 1964 10 Degree Standard Observer
    
                # cmfs=colour.colorimetry.MSDS_CMFS_STANDARD_OBSERVER["CIE 1994 10 Degree Standard Observer"]
                cmfs=colour.colorimetry.MSDS_CMFS_STANDARD_OBSERVER['CIE 1964 10 Degree Standard Observer']
                illuminant=colour.SDS_ILLUMINANTS["D65"]
        
                # Calculating the sample spectral distribution *CIE XYZ* tristimulus values
                XYZ=colour.sd_to_XYZ(sdVA,cmfs,illuminant)
                
                
                print("LMRe-XYZ",XYZ)
    
                Lab=colour.XYZ_to_Lab(XYZ/100)
                print("LMRe-Lab",Lab)
    
    
                # Calculating the sample spectral distribution *CIE XYZ* tristimulus values
                XYZ_Measure=colour.sd_to_XYZ(sdVAmeasure,cmfs,illuminant)
                print("700D-XYZ",XYZ_Measure)
    
                Lab_Measure=colour.XYZ_to_Lab(XYZ_Measure/100)
                print("700D-Lab",Lab_Measure)     
                if ETC==1:  
                    XYZ=colour.sd_to_XYZ(sdVA,cmfs,illuminant)
                    # D65 = colour.SDS_ILLUMINANTS['CIE 1931 2 Degree Standard Observer']['D65']
                    # A = colour.ILLUMINANTS['CIE 1931 2 Degree Standard Observer']['A']
                    # colour.chromatic_adaptation(XYZ, colour.xy_to_XYZ(D65), colour.xy_to_XYZ(A))
                    print("ETC -XYZ",XYZ)
                    
                    Lab=colour.XYZ_to_Lab(XYZ/100)
                    print("ETC-Lab",Lab)
                    
                    if side12=="1-side":
                            LM_result=pd.DataFrame()
                            if os.path.isfile(LMfilename):
                                # 文件存在，我们可以读取它
                                LM_result = pd.read_excel(LMfilename)
                            else:
                                # 文件不存在，我们可以创建一个新的Excel文件
                                LM_result.to_excel(LMfilename)  # 将DataFrame保存到Excel文件中
                            # LM_result=pd.read_excel("C:\\LM\\LM.xlsx",sheet_name="Sheet1")
                            LM_result.loc[Fixpos,'Y5501side']=zVA[15][0]
                            LM_result.loc[Fixpos,'Y1side']=XYZ[1]#这里不用XYZETC 是因为在ETC等于1的时候zVA 就已经是加了ETC之后的数据
                            LM_result.loc[Fixpos,'Ymax1side']=max(zVA[15:-1])[0]
                            LM_result.loc[Fixpos,'L1side']=Lab[0]
                            LM_result.loc[Fixpos,'a1side']=Lab[1]
                            LM_result.loc[Fixpos,'b1side']=Lab[2]
                            LM_result.to_excel(LMfilename,sheet_name="Sheet1",index=False)
                            
                    if side12=="2-side":
                            bareglassvalue=float(values["Bareglass"])
                            LM_result=pd.DataFrame()
                            if os.path.isfile(LMfilename):
                                # 文件存在，我们可以读取它
                                LM_result = pd.read_excel(LMfilename)
                            else:
                                # 文件不存在，我们可以创建一个新的Excel文件
                                LM_result.to_excel(LMfilename)  # 将DataFrame保存到Excel文件中
                            # LM_result=pd.read_excel("C:\\LM\\LM.xlsx",sheet_name="Sheet1")
                            LM_result.loc[Fixpos,'Y550']=zVA[15][0]
                            LM_result.loc[Fixpos,'Ymax']=max(zVA[15:-1])[0]
                            LM_result.loc[Fixpos,'Y']=XYZ[1]
                            LM_result.loc[Fixpos,'L']=Lab[0]
                            LM_result.loc[Fixpos,'a']=Lab[1]
                            LM_result.loc[Fixpos,'b']=Lab[2]
                            LM_result.loc[Fixpos,'Y1side']=XYZ[1]-bareglassvalue
                            LM_result.to_excel(LMfilename,sheet_name="Sheet1",index=False)
                            window.Element('Y2S').Update(XYZ[1])
                            window.Element("L2S").Update(Lab[0])
                            window.Element("a2S").Update(Lab[1])
                            window.Element("b2S").Update(Lab[2])
                            window.Element("Y1S").Update(XYZ[1]-bareglassvalue)

    
    
            filename=imagepath3
            filename1=imagepath4
            window['-IMAGE-'].update(data=convert_to_bytes(filename, resize=new_size))
            window['-IMAGE1-'].update(data=convert_to_bytes(filename1, resize=new_size))
            window.Element('progbar').update_bar(4)
            if ETC==1:
                if side12=="1-side":
                    window.Element('Y1S').Update(XYZ[1])
                    window.Element("L1S").Update(Lab[0])
                    window.Element("a1S").Update(Lab[1])
                    window.Element("b1S").Update(Lab[2])
                if side12=="2-side":
                    window.Element('Y2S').Update(XYZ[1])
                    window.Element("L2S").Update(Lab[0])
                    window.Element("a2S").Update(Lab[1])
                    window.Element("b2S").Update(Lab[2])
    # Imafolder_path = 'C:\\Picture3\\reflesh\\'
    # image_list= os.listdir(Imafolder_path)
    # if event == 'Prev':
    #     # 显示前一张图片
    #     if image_index > 0:
    #         image_index -= 1
    #     window['-IMAGEfle-'].update(data=convert_to_bytes(Imafolder_path+image_list[image_index],resize=new_size))
    # if event == 'Next':
    #     # 显示下一张图片
    #     if image_index < len(image_list) - 1:
    #         image_index += 1
    #     window['-IMAGEfle-'].update(data=convert_to_bytes(Imafolder_path+image_list[image_index],resize=new_size))            
window.close()    

sg.popup('Title',      
            'The results of the window.',      
            'The button clicked was "{}"'.format(event),      
            'The values are', values)      